# Title: Main.py
# Description: Main Interface proof on concept.

# Allows importing from another folder
import sys
sys.path.insert(0, '../')

from Index import *
from FramedText import *
import tkinter as tk

def packSpacer(parent, size, color):
    LabelFrame(parent, height = size, bg = color).pack()


class TitledListBox:
    def __init__(self, sidebar, color="green", padX = 20, font = "Verdana 20", text= "<Title Here>"):
        title = Label(sidebar, text = text, font = font, bg = color)
        title.pack(fill = Y, pady = 20)
        self.results = Listbox(sidebar, selectmode = SINGLE)
        self.results.pack(fill = X, padx = padX)

        self.entries = None

    def bind(self, button, command):
        self.results.bind(button, command)
 
    def populateTags(self, key, index):
        self.results.delete(0, END)
        
        try:
            self.entries = index.lookup(key)
        except KeyError:
            self.entries = []

        for item in self.entries:
                print(item.xmlID())
                self.results.insert(END, item.xmlID())

        self.results.selection_set(0)

    def getXmlId(self):
        return self.results.get(self.results.curselection())
    
    def getSelection(self):
        selection = self.results.curselection()
        if selection is not ():
            return self.entries[selection[0]]
        else:
            return ""

class TitledTextBox:
    def __init__(self, sidebar, color="green", padX = 20, font = "Verdana 20", text =
    "<Title Here>"):
        title = Label(sidebar, text = text, font = font, bg = color)
        title.pack(fill = Y, pady = 20)
        self.results = Text(sidebar)
        self.results.pack(fill = X, padx = padX)

    def updateInformation(self, string):
        self.results.delete(0.0, END)
        self.results.insert(END, string)

class Button_:
    def __init__(self, sidebar, textString, text, padY, command):
        self.button = Button(sidebar, text = textString, command = command)
        self.button.pack(pady = padY)
        

class Sidebar:
    def __init__(self, parentFrame, color, text, index):
        self.TagResults = TitledListBox(parentFrame, text="Tag Results")
        self.confirmButton = Button_(parentFrame, "Confirm", text, 10, lambda: text.insertAround(self.TagResults.getXmlId()))
        packSpacer(parentFrame, 100, "green")
        self.IndexResults = TitledTextBox(parentFrame, text="Tag Information")
        self.tagButton = Button_(parentFrame, "Tag", text, 10, lambda: text.findAndFlag(index))
        
        self.index = index
        self.TagResults.populateTags("Tarkovski_1", self.index)

    def updateInfoHandler(self, event):
        self.updateInfo()
    
    def updateInfo(self):
        entry = self.TagResults.getSelection()
        self.IndexResults.updateInformation(str(entry))
        


