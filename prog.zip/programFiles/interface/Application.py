# Title: Main.py
# Description: Main Interface proof on concept.

# Allows importing from another folder
import sys
sys.path.insert(0, '../')

from FramedText import *
from Sidebar import *
import tkinter as tk


class Application:
    def __init__(self):
        self.index = Index("../../META/test_index.xml")
        
        self.root = tk.Tk()
        self.dim = self._getDim()
        self.FramesLR = self._placeFrames()
        
        self.text = FramedText(self.FramesLR[0])
        self.text.loadText("../../input/astaikina.txt")
        self.text.pack()
        
        self.sidebar = Sidebar(self.FramesLR[1], "green", self.text, self.index)

    def _getDim(self):
        print(self.root.winfo_screenwidth(), self.root.winfo_screenheight())
        return (self.root.winfo_screenwidth(), self.root.winfo_screenheight())

    def _placeFrames(self):

        textFrame = tk.Frame(self.root, height = self.dim[1], width = self.dim[0] / 2)
        textFrame.pack_propagate(0) # Stops frames from shrinking to fit contents.    
        textFrame.pack(expand = True, side = tk.LEFT)
        
        sidebarFrame = tk.Frame(self.root, height = self.dim[1], width = self.dim[0] / 4, bg='green')
        sidebarFrame.pack_propagate(0) 
        sidebarFrame.pack(side = tk.LEFT)
        return (textFrame, sidebarFrame)

    def _updateTags(self, event):
        word = self.text.wordInfo().lower()
        self.sidebar.TagResults.populateTags(word, self.index)
        self.sidebar.updateInfo()

    def bind(self):
        self.sidebar.TagResults.bind("<Button-1>", self.sidebar.updateInfoHandler)
        self.text.bind("<ButtonRelease-1>", self._updateTags)
        print("Good")
        self.sidebar.TagResults.populateTags("", self.index)

    def _makeMenu(self):
        menubar = Menu(self.root)
        filemenu = Menu(menubar, tearoff=0)
        filemenu.add_command(label="Open")
        filemenu.add_command(label="Save")
        filemenu.add_separator()
        filemenu.add_command(label="Export")
        menubar.add_cascade(label="File", menu=filemenu)
        toolsmenu = Menu(menubar, tearoff=0)
        toolsmenu.add_command(label="Hide Greens")
        toolsmenu.add_command(label="Hide Interviewer Text")
        toolsmenu.add_command(label="Iterate")
        toolsmenu.add_separator()
        toolsmenu.add_command(label="Edit index...")
        menubar.add_cascade(label="Tools", menu=toolsmenu)
        self.root.config(menu=menubar)
        

    def launch(self):
        self._makeMenu()

        # Original pre-menu stuff
        self.bind()
        self.root.mainloop()


        
# make root, 
app = Application()
app.launch()

